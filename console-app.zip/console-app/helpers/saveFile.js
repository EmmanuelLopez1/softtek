import fs from "fs"
const db = "./db/tasks.json"

const saveDB = (data)=>{
    fs.writeFileSync(db, JSON.stringify(data))
}

const readDB = ()=>{
    
    if(!fs.existsSync(db)){
        return null
    }
    let info = fs.readFileSync(db, 'utf8')
    
    return JSON.parse(info)
}

export {
    saveDB,
    readDB
}