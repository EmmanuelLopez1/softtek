import inquirer from 'inquirer';
import colors from "colors";


const questions = [
    {
        type: "list",
        name: "ans",
        message: "Select an option",
        choices: [{
            name: `${"1.".green} Crear una tarea.`,
            value: 1
        },
        {
            name: `${"2.".green} Listar tareas.`,
            value: 2,
        },
        {
            name: `${"3.".green} Listar tareas completadas.`,
            value: 3,
        },
        {
            name: `${"4.".green} Listar tareas pendientes.`,
            value: 4
        },
        {
            name: `${"5.".green} Completar tareas`,
            value: 5,
        },
        {
            name: `${"6.".green} Borrar tarea`,
            value: 6,
        },
        {
            name: `${"0.".green} Salir\n`,
            value: 0,
        }]
    }
]

const inquireMenu = async () => {
    console.log("=======================".green)
    console.log("   Select an option    ")
    console.log("=======================\n".green)

    const { ans } = await inquirer.prompt(questions)
    return ans
}

const stop = async ()=>{
    const question = [
        {
            type: "input",
            message:`\nPress ${'Enter'.green} to  continue\n`,
            name:"enter"
        }
    ]
    
    console.log("\n")
    await inquirer.prompt(question)
    
}

const leerInput = async(message)=>{
    const question =  [
        {
            type: "input",
            name: "desc",
            message: message + "\n",
            validate(task){
                if(task.length === 0){
                    return "Please enter a value \n"
                }
                return true;
            }
        }
    ]

    const {desc} = await inquirer.prompt(question)
    return desc
}

const listTasksToDelete = async(tareas=[])=>{
    let choices = tareas.map((task, i)=>{
        const idx = `${i + 1}`.green;
        
        return {
            value:task.id,
            name:`${idx} ${ task.desc }`
        }
    })

    choices.unshift({
        value:0,
        name: `${'0'.green}. Cancel`
    })
    
    const questions = {
        type:'list',
        name: 'id',
        message: 'Borrar',
        choices
    }
    
    const {id} = await inquirer.prompt(questions)
    return id
}

const verifyId = async(message)=>{
    const question = {
        type:"confirm",
        name: 'ok',
        message
    }

    const {ok} = await inquirer.prompt(question)
    return ok;
}

const listTasksToEdit = async(tareas=[])=>{
    let choices = tareas.map((task, i)=>{
        const idx = `${i + 1}`.green;
        
        return {
            value:task.id,
            name:`${idx} ${ task.desc }`,
            checked: (task.completeIn) ? true : false
        }
    })
    
    const question = {
        type:'checkbox',
        name: 'ids',
        message: 'Selects:',
        choices
    }
    
    const {ids} = await inquirer.prompt(question)
    return ids
}

export { 
    inquireMenu, 
    stop, 
    leerInput,
    listTasksToDelete,
    listTasksToEdit,
    verifyId,
}