import colors from "colors";
import { 
        inquireMenu, 
        leerInput, 
        stop, 
        listTasksToDelete,
        listTasksToEdit,
        verifyId } from "./helpers/inquirer.js";
import { saveDB, readDB } from "./helpers/saveFile.js";
import Tareas from "./models/Tareas.js";


const main = async()=>{
    
    let opt = ""
    const tareas = new Tareas()
    const tasksDB = readDB()

    if(tasksDB){
        tareas.loadListadoArr(tasksDB)   
    }
    
    do{
        console.clear()

        opt = await inquireMenu()
        
        switch (opt) {
            case 1:
                const new_task = await leerInput("Task description:")
                tareas.crearTarea(new_task)
                break;
            case 2:
                tareas.listTasks(3)
                break;
            case 3:
                tareas.listTasksCompleted()
                break;
            case 4: 
                tareas.listTasksCompleted(false)
                break;
            case 5:
                const ids = await listTasksToEdit(tareas.listadoArr)
                tareas.toggleTaskCompleteStatus(ids)
                console.log(ids)
                break;
            case 6:
                const id = await listTasksToDelete(tareas.listadoArr)
                if(id !== 0){
                    const ok = await verifyId('Are you sure to delete it?')
                    if(ok){
                        tareas.deleteTask(id)
                        console.log("Task deleted succesfully".green);
                    }
                }
                break;
        }

        saveDB(tareas.listadoArr)
        
        await stop()

    }while(opt !== 0)

}

main()