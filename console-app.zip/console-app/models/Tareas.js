import Tarea from "./tarea.js"

class Tareas {
    constructor(){
        this.listado = {}
    }

    get listadoArr (){
        const listado = []

        Object.keys(this.listado).forEach(key =>{
            const task = this.listado[key]
            listado.push(task)
        })

        return listado;
    }

    deleteTask( id = ''){
        if(this.listado[id]){
            delete this.listado[id]
        }
    }

    loadListadoArr(tasks = []){
        tasks.forEach(task=>{
            this.listado[task.id] = task
        })
    }

    crearTarea(desc = ''){
        const tarea = new Tarea(desc)
        this.listado[tarea.id] = tarea 
    }

    verifyTaskCompleted(task, index){
        if(task.completeIn !== null){
            return `${index}. ${task.desc} ${':: Completado'.green}`
        }
        return `${index}. ${task.desc} ${':: Pendiente'.red}`
    }

    listTasks(){
        console.log()
        let task_number = 1
        this.listadoArr.forEach((task)=>{
            if(task.completeIn !== null){
                console.log(this.verifyTaskCompleted(task, task_number))
                task_number++
                return
            }
            console.log(this.verifyTaskCompleted(task, task_number))
            task_number++
        })
    }

    listTasksCompleted(completed = true){
        console.log()
        let task_number = 1
        this.listadoArr.forEach(task=>{
            if(completed){
                if(task.completeIn !== null){
                    console.log(this.verifyTaskCompleted(task, task_number)) 
                    task_number++
                }
            }else{
                if(task.completeIn === null){
                    console.log(this.verifyTaskCompleted(task, task_number)) 
                    task_number++
                }
            }
        })
    }

    toggleTaskCompleteStatus(ids = []){
        ids.forEach(id=>{
            const task = this.listado[id]
            
            if(!task.completeIn){
                task.completeIn = new Date().toISOString()
            }
        })

        this.listadoArr.forEach(task=>{
            if(!ids.includes(task.id)){
                task.completeIn = null
            }
        })
    }
}

export default Tareas