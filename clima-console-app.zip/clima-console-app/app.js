import { inquirerMenu, leerInput, pausa, listarLugares } from "./helpers/inquirer.js";
import Busquedas from "./models/busqueda.js"
import dotenv from "dotenv"
dotenv.config()

const main = async()=>{
    const busquedas = new Busquedas()
    busquedas.leerDb()
    let menu_opt;

    do {
        menu_opt = await inquirerMenu()
        switch (menu_opt) {
            case 1:{
                //mostrar mensaje
                const lugar = await leerInput("Ciudad: ")

                //buscar los lugares
                const places = await busquedas.ciudad(lugar)
                // seleccionar el lugar
                const id = await listarLugares(places)
                console.log(id);
                if(id === "0") break;

                const placeSelected = places.find(place => id === place.id)

                console.log(placeSelected);
                // Clima data
                const weather = await busquedas.climaLugar(placeSelected.lat, placeSelected.lng)
                console.log(weather);
                // mostrar resultados
                console.log("\nInformacion de la ciudad:\n".green);
                console.log("Ciudad:", placeSelected.name);
                console.log("Lng:", placeSelected.lng);
                console.log("Lat:", placeSelected.lat);
                console.log("Temperatura:", weather.temp);
                console.log("Minima:", weather.min);
                console.log("Maxima:",weather.max);
                console.log("Description:", weather.desc);

                busquedas.agregarHistorial(placeSelected.name)
            }
                break;
            case 2:{
                busquedas.historial.forEach((place, idx)=>{
                    idx = `${idx + 1}.`.green
                    console.log(idx + ` ${place}`);
                })
            }
                break;
        }

        if(menu_opt !== 0) await pausa()
    } while (menu_opt !== 0);

}
main()
