import https from "https"
import fs from "fs"
import axios from "axios";
import { log } from "console";

class Busquedas {
    constructor() {
        this.historial = []
        this.dbPath = "./db/database.json"
        // Leer db si existe
    }

    get paramsMapBox() {
        return {
            "limit": "5",
            "access_token": process.env.MAPBOX_KEY,
            "proximity": "ip",
            "types": "region,place,postcode,address,neighborhood",
        }
    }

    async ciudad(lugar = "") {
        //peticion http
        const instance = axios.create({
            baseURL: `https://api.mapbox.com/geocoding/v5/mapbox.places/${lugar}.json`,
            params: this.paramsMapBox,
            httpsAgent: new https.Agent({
                rejectUnauthorized: false
            })
        })


        const data = await instance.get()
            .then(({ data }) => {
                return data.features.map(place => ({
                    id: place.id,
                    name: place.place_name,
                    lng: place.center[0],
                    lat: place.center[1]
                }))
            })
            .catch(err => {
                if (err.response) {
                    // The request was made and the server responded with a status code
                    // that falls out of the range of 2xx
                    console.log(err.response.data);
                    console.log(err.response.status);
                    console.log(err.response.headers);
                } else if (err.request) {
                    // The request was made but no response was received
                    // `err.request` is an instance of XMLHttpRequest in the browser and an instance of
                    // http.ClientRequest in node.js
                    console.log(err.request);
                } else {
                    // Something happened in setting up the request that triggered an err
                    console.log('err', err.message);
                }
                return []
            })
            
        data.shift({value:0, name:"0 salir"})
        return data
    }

    get getParamsWeather(){
        return{
            "appid":process.env.OPEN_WEATHER_KEY,
            "units":"metric",
            "lang":"es",
        }
    }

    async climaLugar (lat, lon){
        try{
            // axios instance
            const instance = axios.create({
                baseURL:"https://api.openweathermap.org/data/2.5/weather",
                params:{...this.getParamsWeather, lat, lon},
                httpsAgent: new https.Agent({
                    rejectUnauthorized: false
                })
            })
            
            const {data} = await instance.get()
            console.log(data);
            const {weather, main} = data
            // res.data
            return{
                desc:weather[0].description,
                min:main.temp_min,
                max:main.temp_max,
                temp:main.temp
            }

        }catch(err){
            return err
        }
    }
    
    agregarHistorial(lugar = ""){
        if(this.historial.includes(lugar.toLocaleLowerCase)){
            return 
        }
        this.historial = this.historial.splice(0, 5)

        this.historial.unshift(lugar)
        this.writeDb()
    }

    leerDb(){
        if(!fs.existsSync(this.dbPath)) return;

        let data = fs.readFileSync(this.dbPath, {encoding:"utf-8"})
        if(data.length > 0){
            const {historial} = JSON.parse(data)
            this.historial = historial

        }
    }

    writeDb(){
        const payload = {
            historial: this.historial
        }
        fs.writeFileSync(this.dbPath, JSON.stringify(payload))
    }
}

export default Busquedas