class Form {
    constructor(controls, action){
        this.controls = controls
        this.action = action
    } 

    getContent(){
        return `
            <br>
            <form method="post" action="${this.action}" >
                ${this.controls.reduce((ac,c)=>{
                    return ac + `
                        <div>
                            ${this.getLabel(c)}
                            ${this.getInput(c)}
                        </div>
                    `
                }, "")}

                <button>
                    Enviar
                </button>
            </form>
            <br>
            <hr>
        `
    }

    getLabel(control){
        return `<label>${control.text}</label>`
    }

    getInput(control){
        return `
        <input type="${control.type}"
            id="${control.name}"
            name="${control.name}"
        />`
    }
}

class FormBuilder{
    constructor(){
        this.reset()
    }

    reset(){
        this.action = ""
        this.controls = []
    }

    setAction(action){
        this.action = action
        return this
    }

    setText(name, text){
        this.controls.push({
            name,
            text,
            type:"text"
        })
        return this
    }

    setEmail(name, text){
        this.controls.push({
            name,
            text,
            type:"email"
        })
        return this
    }

    setCheckBox(name, text){
        this.controls.push({
            name,
            text,
            type:"checkbox"
        })
        return this
    }

    build(){
        const frm = new Form(this.controls, this.action)
        this.reset()
        return frm;
    }
}

class FormDirector{
    constructor(formBuilder){
        this.setBuilder(formBuilder)
    }

    setBuilder(formBuilder){
        this.formBuilder = formBuilder
    }

    createPeopleForm(){
        const formBuilder = this.formBuilder
        formBuilder.reset()
        formBuilder.setText("firstname", "nombre")
            .setText("lastname", "apellidos")
    }

    createContactForm(){
        this.formBuilder.reset()
        this.formBuilder.setText("name","Nombre del interesado")
            .setEmail("email", "Correo electronico")
            .setText("message", "Mensaje")
    }
}

const frmBuilder = new FormBuilder()
const formPeople = frmBuilder.setAction("add.php")
                             .setText("firstname", "Nombre")
                             .setText("lastName", "Apellido")
                             .setCheckBox("drinker", "¿Te gusta pistear?")
                             .build();
form1.innerHTML = formPeople.getContent()

const formMail = frmBuilder.setAction("send.php")
                    .setText("name", "Nombre")
                    .setEmail("email", "Correo Electronico")
                    .build()

form2.innerHTML = formMail.getContent()

const director = new FormDirector(frmBuilder)
director.createPeopleForm()
form3.innerHTML = frmBuilder.build().getContent()
director.createPeopleForm()
form4.innerHTML = frmBuilder.build().getContent()
director.createContactForm()
form5.innerHTML = frmBuilder.build().getContent()