/*
    STATE:
    -PATRON DE COMPORTAMIENTO.
    -VAMOS A TENER UN AMBITO O CONTEXTO EL CUAL PUEDE TENER UN ESTADO ESTABLECIDO Y 
    DEPENDIENDO ESTE ESTADO VA A SER SU COMPORTAMIENTO.
    -PUEDE COMPARTIR CONOCIMIENTO ENTRE SUS MISMAS CLASES QUE VAN A SER LOS ESTADOS 
    Y PUEDEN CAMBIAR DE ESTADO AL OBJETO PRINCIPAL.
*/ 

class DocumentContext {
    constructor(){
        this.content = ""
        this.state = new BlankState()
    }

    setState(state){
        this.state = state
    }

    write(text){
        this.state.write(this, text)
    }
}

class BlankState{
    write(documentContext, text){
        documentContext.content = text
        documentContext.setState(new WithContentState())
    }
}

class WithContentState{
    write(documentContext, text){
        documentContext.content += " " + text
        documentContext.setState(new WithContentState())
    }
}

class ApprovedState {
    write(documentContext, text){
        console.log("documento aprobado, ya no se modifica");
    }
}

const doc = new DocumentContext()
console.log(doc.state)
doc.write("weed")
console.log(doc.content)
console.log(doc.state)
doc.write("ALGO")
doc.write("MAS")
console.log(doc.content);

doc.setState(new ApprovedState())
doc.write("pito")
console.log(doc.state);