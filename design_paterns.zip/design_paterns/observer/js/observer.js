/*
    ES UN PATRON DE COMPORTAMIENTO.
    SIRVE PARA NOTIFICAR A UN OBJETO O GRUPO DE OBJETOS CUANDO UN DATO 
    EN EL QUE ESTAN INTERESADOS O SUSCRITOS SE ACTUALIZA
*/

class Subject {
    constructor(){
        this.observers = []
    }

    subscribe(observer){
        this.observers.push(observer)
    }

    unsubscribe(observer){
        this.observers = this.observers.filter(obs => obs !== observer)
    }

    notify(data){
        this.observers.forEach(e=>e.refresh(data))
    }
}

class Observer{
    constructor(fn){
        this.fn = fn
    }

    refresh(data){
        this.fn(data)
    }
}

const s = new Subject()
const ob1 = new Observer(d=>console.log("Soy el observador 1 " + d))
const ob2 = new Observer(d=>console.log("Soy el observador 2 " + d))

s.subscribe(ob1)
s.subscribe(ob2)

console.log();

function change(){
    s.notify(myText.value)
}