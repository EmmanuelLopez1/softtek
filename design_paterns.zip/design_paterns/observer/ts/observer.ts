interface IObserver <T>{
    refresh(value: T):void
}

interface ISubject <T>{
    observers:IObserver<T>[]
    subscribe(observer:IObserver<T>):void;
    unsubscribe(observer:IObserver<T>):void;
    notify(value:T) : void
}

class Subject<T> implements ISubject<T>{
    observers: IObserver<T>[];
    constructor(){
        this.observers = []
    }
    subscribe(observer: IObserver<T>): void {
        this.observers.push(observer)
    }
    unsubscribe(observer: IObserver<T>): void {
        this.observers = this.observers.filter(ob=>ob!==observer)
    }
    notify(value: T): void {
        this.observers.forEach(ob=>{
            ob.refresh(value)
        })
    }
}

class Observer<T> implements IObserver<T>{
    private fn:(value:T)=>void;

    constructor(fn:(value:T)=>void){
        this.fn = fn
    }

    refresh(value: T): void {
        this.fn(value)
    }
}

const subject = new Subject<number>();
const observer1 = new Observer<number>((n)=>{
    console.log(`Hello baby ${n}`)
});

const observer2 = new Observer<number>((n)=>{
    console.log("Hello softtek" + n );
})

subject.subscribe(observer1)
subject.subscribe(observer2)
// subject.notify(1.2)
subject.notify(30)

const strSubject = new Subject<string>()
const strobserver1 = new Observer<string>((str)=>{
    console.log(`Hello ${str.toUpperCase()}`);
})

const strobserver2 = new Observer<string>((str)=>{
    console.log(`Hello ${str.toLowerCase()}`);
})

strSubject.subscribe(strobserver1)
strSubject.subscribe(strobserver2)
strSubject.notify("Maxo")