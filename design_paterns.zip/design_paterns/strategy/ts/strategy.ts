interface Strategy{
    login(user:string, password:string) : boolean;
}


class LoginContext {
    private strategy: Strategy;
    
    constructor(strategy:Strategy){
        this.strategy = strategy
    }

    setStrategy(strategy: Strategy){
        this.strategy = strategy
    }

    login(user:string, password:string) : boolean{
        return this.strategy.login(user, password)
    }
}

class loginDbStrategy implements Strategy{
    login(user:string, password:string) : boolean{
        console.log("simulando la base de datos");
        
        if(user === "maxo" && password === "baby"){
            return true
        }
        return false
    }
}

class loginServicetrategy implements Strategy{
    login(user:string, password:string) : boolean{
        console.log("nos dirigimos a un webservice");
        
        if(user === "web" && password === "service"){
            return true
        }
        return false
    }
}

const auth = new LoginContext(new loginDbStrategy())
const webService = new loginServicetrategy()
console.log(auth.login("maxo", "weed"));
auth.setStrategy(webService)
console.log(auth.login("web", "service"));