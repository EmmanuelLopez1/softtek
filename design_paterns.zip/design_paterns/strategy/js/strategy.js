/*
    PATRON DE COMPORTAMIENTO STRATEGY:
    NOS PERMITE TENER COMPORTAMIENTOS DISTINTOS EN UN OBJETO Y AGREGARLE NUEVOS COMPORTAMIENTOS SIN
    --MODIFICAR EL CONTEXTO INICIAL. 
    --NOS SIRVE CUANDO TENGAMOS COMPORTAMIENTOS EN UN OBJETO QUE VAN A CAMBIAR EN TIEMPO DE EJECUCION.
    --ES UTIL CUANDO TENEMOS MUCHOS IF O SWITCH CASE EN LOS CUALES DENTRO DE ELLOS TENEMOS COMPORTAMIENTOS.

    CONTEXTO: Es el objeto central que unifica las cosas.
*/

// class SaleContext {
//     constructor(strategy){
//         this.strategy = strategy
//     }

//     setStrategy(strategy){
//         this.strategy = strategy
//     }

//     calculate(amount){
//         return this.strategy.calculate(amount)
//     }
// }

// class RegularSaleStrategy {
//     constructor(tax){
//         this.tax = tax
//     }

//     calculate(amount){
//         return amount + (amount * this.tax)
//     }
// }

// class DiscountSaleStrategy extends RegularSaleStrategy{
//     constructor(tax, discount){
//         super(tax)
//         this.tax = tax
//         this.discount = discount
//     }

//     calculate(amount){
//         return super.calculate(amount) - this.discount
//     }
// }

// const regularSale = new RegularSaleStrategy(0.16)
// const discountSale = new DiscountSaleStrategy(0.16, 16)
// const sale = new SaleContext(regularSale)

// sale.setStrategy(discountSale)
// // console.log(sale.calculate(100));
// console.log(sale.calculate(100));




/*
    EXPLICACION PRACTICA
*/

const players = [
    {
        name: 'Ronaldhino Gaucho',
        number: 10,
        team: 'Barcelona Fc',
    },
    {
        name: 'Lionel Messi',
        number: 10,
        team: 'Paris Saint Germain',
    },
    {
        name: 'CR7',
        number: 7,
        team: 'Manchester United',
    },
]


class InfoContext {
    constructor(strategy, data, element) {
        this.setStrategy(strategy)
        this.data = data
        this.element = element
    }

    setStrategy(strategy) {
        this.strategy = strategy
    }

    show() {
        this.strategy.show(this.data, this.element)
    }
}



class ListStrategy {
    show(data, element) {
        element.innerHTML = data.reduce((ac, item) => {
            return ac + `
                    <div>
                        <h2>${item.name}</h2>
                        <p>${item.team}</p>
                    </div>
                    <hr/>
                `
        }, "")
    }
}

class DetailedStrategy {
    show(data, element) {
        element.innerHTML = data.reduce((ac, item) => {
            return ac + `
                    <div>
                        <h2>${item.name}</h2>
                        <p>${item.team}</p>
                        <p>${item.number}</p>
                    </div>
                    <hr/>
                `
        }, "")
    }
}



const info = new InfoContext(new ListStrategy, players, content)
info.show()

const strategies = [
    new ListStrategy(),
    new DetailedStrategy()
]

slcOptions.addEventListener('change', (e)=>{
    console.log(e.target.value);
    const op = e.target.value 
    info.setStrategy(strategies[op])
    info.show()
})









