/*
    PATRON DE DISEÑO DE TIPO ESTRUCTURA.
    -NOS AYUDA A DAR FUNCIONALIDADES EXTRA A UNA CLASE SIN MODIFICAR LA FUNCIONALIDAD ORIGINAL.
    -SOLUCIONA COMO ESTAN ESTRUCTURADAS LAS CLASES, COMO SE CONFORMAN UNAS CON OTRAS.
    -AYUDA CUANDO LE TENEMOS QUE AGREGAR MUCHAS FUNCIONALIDADES JERARQUICAMNETE A UN CONJUNTO DE CLASES.
    -NOS PERMITE HEREDAR COMPORTAMIENTOS DE MAS DE UNA CLASE.
*/ 


// COMPONENT O CLASE PRINCIPAL
// EN JAVASCRIPT AL NO HABER INTERACES EL COMPONENT REPRESENTA Component Y ConcreteComponent DE UN DIAGRAMA UML.
class ProductComponent {
    constructor(name){
        this.name = name
    }

    getDetail(){
        return this.name
    }
}

// main decorator
// los decoradores envuelven una funcionalidad, pueden envolver otros decoradores.
class ProductDecorator {
    constructor(ProductComponent){
        this.ProductComponent = ProductComponent
    }

    getDetail(){
        return this.ProductComponent.getDetail()
    }
}

// DECORATOR 1
class StoreProductDecorator  extends ProductDecorator{
    constructor(productComponent, price){
        super(productComponent)
        this.price = price
    }

    getDetail(){
        return super.getDetail() + ` $${this.price}`
    }
}

// DECORATOR 2
class CommercialInfoProductDecorator extends ProductDecorator{
    constructor(ProductDecorator, tradname, brand){
        super(ProductDecorator)
        this.tradname = tradname
        this.brand = brand
    }

    getDetail(){
        return `${this.tradname} ${this.brand}  ` + super.getDetail()
    }
}

// DECORATOR 3
class HTMLProductDecorator extends ProductDecorator{
    getDetail(){
        return `
            <h1>Informacion del producto</h1>
            <p>
                ${super.getDetail()}
            </p>
        `
    }
}


// EJECUCION COMPONENT
const productComponent = new ProductComponent("Cerveza")
console.log(productComponent.getDetail());

// DECORADOR 1 CON COMPONENTE
const commercialInfoProduct = new CommercialInfoProductDecorator(productComponent, "London Porter", "Fuller's")
console.log(commercialInfoProduct.getDetail());

// DECORADOR 2 CON COMPONENTE
const storeProduct = new StoreProductDecorator(productComponent, 200)
console.log(storeProduct.getDetail());

// DECORADOR 2 CON DECORADOR 1
const product = new StoreProductDecorator(commercialInfoProduct, 100)
console.log(product.getDetail());

// decorator 3 con decorator 2 con decorator 1
const   htmlProductDecorator = new HTMLProductDecorator(product)
console.log(htmlProductDecorator.getDetail());
myDiv.innerHTML = htmlProductDecorator.getDetail()