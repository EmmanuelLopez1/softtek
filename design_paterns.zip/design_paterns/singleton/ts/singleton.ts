// LOS VALORES ESTATICOS PERTENECEN A LA CLASE.
// LOS VALORES NORMALES, PERTENECEN AL OBJETO.

class Singleton{
    private static instance: Singleton;
    random: number;

    private constructor(){
        this.random = Math.random()
    }

    public static getInstance(): Singleton{
        if(!this.instance){
            this.instance = new Singleton
        }
        return this.instance
    }
}


const singleton = Singleton.getInstance()
const singleton2 = Singleton.getInstance()

console.log(singleton);
console.log(singleton2);

