// SIRVE HACER QUE SOLO EXISTA UNA INSTACIA DE UNA CLASE.
// ES UN PATRON CREACIONAL, YA QUE NOS ESTA DANDO UNA TECNICA PARA CREAR OBJETOS.
// SE PUEDE USAR CUANDO LA PERSISTENCIA DE LA INFORMACION DE UN OBJETO NUNCA VA A CAMBIAR.

// TEORIA
// class Singleton {
//     static (){
//         return Singleton.instance
//     }

//     constructor(){
//         this.random = Math.random()
//         if(Singleton.instance){
//             return Singleton.instance
//         }
//         Singleton.instance = this
//     }
// }

// const single1 = new Singleton("maxo")
// const single2 = new Singleton("baby")

// console.log(single1);
// console.log(single2);

// console.log(single1 === single2);


/*
    TYPESCRIPT
*/ 
