/*
    BRIDGE:
    -LA INTERFAZ ES EL DISPARADOR DE LOS EVENTOS Y ADMITE DIFERENTES IMPLEMENTACIONES.
    -LA IMPLEMENTACION CAMBIA CAMBIA DEPENDIENDO DE LA ABSTRACCION.
    -PATRON ESTRUCTURAL.
    -EL FUNCIONAMIENTO ABSTRACTO ES EL MISMO SIMPLEMENTE CAMBIAN LAS HERRAMIENTAS UTILIZADAS.
*/

class EncoderTextAbstraction {
    constructor(encoder) {
        this.encoder = encoder
    }

    encode(str) {
        return this.encoder.encode(str)
    }

    undecode(str){
        return this.encoder.undecode(str)
    }
}

class Base64EncoderImplementor{
    encode(str){
        return window.btoa(unescape(encodeURI(str)))
    }

    undecode(str){
        return decodeURIComponent(escape(window.atob(str)))
    }
}

class HTMLEncoderImplementor {
    encode(str){
        return str.split(/\./g).reduce((ac, e)=>{
            return ac + `<p>${e.trim()}</p>`
        }, "")
    }

    undecode(str){
        return str.split("</p>").reduce((ac, e)=>{
            return  e !== "" ? ac + e.replace("<p>", "") + ". " : ac + ""
        }, "")
    }
}

const encoder1 = new EncoderTextAbstraction(new Base64EncoderImplementor())
console.log(encoder1.encode("pato"));
console.log(encoder1.undecode("cGF0bw=="));

const encoder2 = new EncoderTextAbstraction(new HTMLEncoderImplementor())
console.log(encoder2.encode("baby baby. Hello my friend. Mexico will gain the game"));
console.log(encoder2.undecode("<p>baby baby</p><p>Hello my friend</p><p>Mexico will gain the game</p>"));