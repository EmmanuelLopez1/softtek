import mongoose, { Schema } from "mongoose";
import uniqueValidator from "mongoose-unique-validator";
import slugify from 'slugify';

    const userSchema = new Schema({
            slug:String,
            title:{
                type:String,
                required:true
            },
            date:{
                type: Date,
                required:true
            },
            content:{
                type:true,
                required:true
            }
        })
export default mongoose.model("Entry", userSchema)