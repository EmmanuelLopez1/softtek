import {Schema, model} from "mongoose"

const entrySchema = new Schema({
    date:{
        type:Date,
        required:[true, "date is required"]
    },
    title:{
        type:String,
        required:false,
    },
    text:{
        type:String,
        required:[true, "text is required"]
    }
})

export default model("entrie", entrySchema)