import {Router} from "express"
import { check } from "express-validator"
import { 
    getEntries, 
    getEntry,
    createEntry 
} from "../controllers/entries.js"



const router = Router()

// get unique entry
router.get('/:_id', getEntry)

// get all entries
router.get('/', getEntries)

// new entry
router.post('/', [
    // check('title', "Title is required").not().isEmpty(),
    check('text', 'Text is required').not().isEmpty()
],
createEntry)



export default router;