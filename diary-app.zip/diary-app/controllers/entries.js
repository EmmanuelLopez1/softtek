import entry from "../models/entry.js"
import Entry from "../models/entry.js"

const getEntry = async (req, res) => {
    try {
        const { _id } = req.params

        const entryFinded = await Entry.find({ _id })
        res.set('Content-Type', 'application/json')
        res.status(200)
        return res.json(entryFinded)
    } catch (error) {
        console.log(error);
        throw new Error("ocurrio un error en la base de datos")
    }


}

const getEntries = async (req, res) => {
    console.log("get entries controller");
    try {
        const entries = await Entry.find({}).sort({date:-1})
        res.set('Content-Type', 'application/json')
        res.status(200)
        res.json(entries)
    } catch (error) {
        console.log(error);
        throw new Error("Ocurrio un error en la base de datos")
    }
}

const createEntry = async (req, res) => {
    try {
        let { title, text, date } = req.body

        let entry = new Entry({
            date: date || new Date(),
            title,
            text
        })
        await entry.save()

        res.set('Content-Type', 'application/json')
        res.status(200)
        res.json(entry)
    } catch (error) {
        console.log(error);
        throw new Error("ocurrio un error en la base de datos")
    }
}

export {
    getEntries,
    getEntry,
    createEntry
}
