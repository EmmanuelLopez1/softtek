import './style.css'
// import Product from './clean-code/05-dry'
import './solid/03-liskov-a'


const app = document.querySelector<HTMLDivElement>('#app')!

app.innerHTML = `
  <h1>CleanCode y SOLID</h1>
  <span>Revisar la consola de JavaScript</span>
`

// const product = new Product("maxo", 10, "M")
// console.log(product.toString());
