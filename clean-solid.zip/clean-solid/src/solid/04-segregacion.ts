interface Bird{
    eat()  : void;
}

interface FlyingBird{
    fly()  : void;
}

interface RunningBird {
    run()  : void;
}

interface SwmmingBird {
    swim() : void;
}

class Tucan implements Bird,FlyingBird{
    public fly(){}
    public eat(){}
}

class HumminBird implements Bird, FlyingBird{
    public fly(){}
    public eat(){}
}

class Ostrich {
    public fly(){
        throw Error("Esta fucking ave no vuela");
    }
    public eat(){}  
}

class Penguin implements Bird, SwmmingBird{
    public eat(){}
    public swim(){}
}