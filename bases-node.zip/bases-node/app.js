const {crearArchivo} = require("./helpers/multiplicar")
const argv = require("./config/yargs")


                
console.log(argv)

const {base, list, hasta} = argv

crearArchivo(base, list, hasta)
    .then(nombreArchivo => console.log(nombreArchivo, "creado"))
    .catch(err => console.log(err))

