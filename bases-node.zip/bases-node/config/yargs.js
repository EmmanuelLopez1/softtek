const argv = require('yargs/yargs')(process.argv.slice(2))
                .option('b', {
                    alias: 'base',
                    type: 'number',
                    demandOption:true,
                    describe: "Base of multiply table."
                })
                .options('l', {
                    alias:'list',
                    type:'boolean',
                    default:false,
                    describe:"Show table in console."
                })
                .option('h', {
                    alias:'hasta',
                    type:'number',
                    default:false,
                    describe:"Print table until n number"
                })
                .check((argv, options)=>{
                    if(isNaN(argv.b)){
                        throw "Base need to be a number";
                    }
                    return true
                }).argv;

module.exports = argv