import jwt from "jsonwebtoken"
import User from "../models/user.js"

const generateJTW = (uid = '')=>{
    return new Promise((resolve, reject)=>{
        const payload = {uid}

        jwt.sign(payload, process.env.JWT_SECRET_KEY, {
            expiresIn:'100d'
        },(err, token)=>{
            if(err){
                console.log(err);
                reject('Couldnt generate token')
            }else{
                resolve(token)
            }
        })
    })
}

const verifyJWT = async( token = '')=>{
    try {
        
        // console.log(token);
        if(token.length < 1){
            return null;
        }

        const { uid } = jwt.verify( token, process.env.JWT_SECRET_KEY )
        const user = await User.findById( uid )

        if(user){
            if(user.state){
                return user
            }
            return null
        }else{
            return null
        }
    } catch (error) {
        return null;
    }
}

export {
    generateJTW,
    verifyJWT
}