let user = null;
let socket = null;
const url = 'http://localhost:3000/api/auth/';

// REFERENCIAS HTML
const txtUid = document.querySelector("#txtUid")
const txtMensaje = document.querySelector("#txtMensaje")
const ulUsuarios = document.querySelector("#ulUsuarios")
const ulMensajes = document.querySelector("#ulMensajes")
const btnSalir = document.querySelector("#btnSalir")

const validateJWT = async()=>{
    const token = localStorage.getItem('token') || ''

    if(token.length <= 10){
        window.location = 'index.html'
        throw new Error('There arent token in server')
    }

    const res = await fetch(url, {
        headers:{
            'x-token':token
        }
    })

    const {authenticatedUser:userDB, token:tokenDB} = await res.json()
    localStorage.setItem('token', tokenDB)
    localStorage.setItem('userId', userDB.uid)
    console.log(userDB);
    user = userDB
    await connectSocket()
}

const connectSocket = async()=>{
    socket = io({
        'extraHeaders':{
            'x-token':localStorage.getItem("token")
        }
    })

    socket.on('connect', ()=>{
        console.log("sockets online");
    })

    socket.on('disconnect', ()=>{
        console.log("sockets offline");
    })

    socket.on('recibir-mensajes', dibujarMensajes)

    socket.on('usuarios-activos', dibujarUsuarios)

    socket.on('mensaje-privado', (payload)=>{
        console.log('privado',payload);
    })
}

const dibujarUsuarios = ( usuarios = [] )=>{
    let usersHtml = '';
    usuarios.forEach( ({name, uid})=>{
        usersHtml += `
            <li>
                <p>
                    <h5 class="text-success">${ name }</h5>
                    <span class="fs-6 text-muted">${uid}</span>
                </p>
            </li>
        `
    })

    ulUsuarios.innerHTML = usersHtml;
}

const dibujarMensajes = ( mensajes = [] )=>{
    console.log(mensajes);
    let mensajesHtml = '';
    mensajes.forEach( ({nombre, mensaje})=>{
        mensajesHtml += `
            <li>
                <p>
                    <span class="text-primary">${ nombre }:</span>
                    <span>${ mensaje }</span>
                </p>
            </li>
        `
    })

    ulMensajes.innerHTML = mensajesHtml;
}

txtMensaje.addEventListener('keyup', ({ keyCode })=>{
    if( keyCode !== 13){return}

    const uid = txtUid.value
    const mensaje = txtMensaje.value

    if(mensaje.length <= ''){return}

    socket.emit('enviar-mensaje', { mensaje, uid })

    txtMensaje.value = '';
})

const main = async()=>{
    await validateJWT()
}

main()

// const socket = io()