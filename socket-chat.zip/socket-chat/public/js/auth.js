// HTML REFERENCES
const myForm = document.querySelector("form")

// CONSTANTS
const url = 'http://localhost:3000/api/auth/'

myForm.addEventListener('submit', (e)=>{
    e.preventDefault()
    const formData = {}

    for(let el of myForm.elements){
        if(el.name.length > 0){
            formData[el.name] = el.value
        }   
    }
    fetch(url + 'login', {
        method:'post',
        body:JSON.stringify(formData),
        headers:{
            'Content-Type':'application/json'
        }
    })
    .then(json=>{
        return json.json()
    })
    .then(({errors, token})=>{
        if(errors){
            console.log(errors);
            return
        }
        localStorage.setItem('token', token)
        window.location = 'chat.html'
    })
})

function handleCredentialResponse(response) {
    // google token
    const body = { id_token:response.credential }
    fetch(url + `google`, {
        method: "post",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(body)
    })
        .then((res) => res.json())
        .then(({token}) => {
            localStorage.setItem('token', token)
            window.location = 'chat.html'
        })
        .catch(console.warn)
}
const googleSignOut = document.getElementById("google_signout")

googleSignOut.addEventListener("click",()=>{
    google.accounts.id.disableAutoSelect()
    google.accounts.id.revoke( localStorage.getItem("email"), done=>{
        localStorage.clear()
        location.reload()
    } )
})