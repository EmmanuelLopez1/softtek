import { Socket } from "socket.io"
import { verifyJWT } from "../helpers/generateJWT.js"
import ChatMensajes from "../models/chat-mensajes.js";
const chatMensajes = new ChatMensajes()

const socketController = async(socket, io)=>{
    const user = await verifyJWT(socket.handshake.headers['x-token']);
    if(!user){
        return socket.disconnect()
    }

    // agregar el usuario conectado
    chatMensajes.conectarUsuario(user)
    io.emit('usuarios-activos', chatMensajes.usuariosArr)
    socket.emit('recibir-mensajes', chatMensajes.ultimos10)

    // conectarlo a una sala especial
    socket.join( user.id ) // global, socket.id, user.id

    // desconectar usuario
    socket.on('disconnect', (id)=>{
        chatMensajes.desconectarUsuario(user.id)
        io.emit('usuarios-activos', chatMensajes.usuariosArr)
    })

    socket.on('enviar-mensaje', ({ mensaje, uid })=>{
        if(uid){
            // mensaje privado
            socket.to( uid ).emit('mensaje-privado', {from:user.nombre, mensaje})
        }else{
            chatMensajes.enviarMensaje( uid, user.name, mensaje)
            io.emit('recibir-mensajes', chatMensajes.ultimos10)
        }
    })
    
}

export default socketController