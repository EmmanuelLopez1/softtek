import colors from "colors"
import Entry from "./Entry.js"

class Diary {
    constructor(){
        this.entries = {}
    }

    deleteEntry(id){
        if(this.entries[id]){
            delete this.entries[id]
            return true
        }
        return undefined
    }

    addEntry(entry){
        this.entries[entry.id] = entry
    }

    loadEntries(entries){
        this.entries = entries
    }

    get getEntriesArr(){
        const entries = []
        Object.keys(this.entries).forEach(entry=>{
            entries.push(this.entries[entry])
        })
        return entries
    }

    showEntry(entry){
        const {year, month, day, hour} = new Entry().getDate(entry.date)  
        const separator = `\n------------------`

        return `\n${separator}`
                +
                `\n${year}\\${month}\\${day} - ${hour}`.bold.blue
                + 
                separator
                +
                `\n${entry.title}`.bold.blue
                +
                `\n   ${entry.content}`.green;
    }
}

export default Diary