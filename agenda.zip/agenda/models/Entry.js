import { v4 as uuidv4 } from 'uuid';
class Entry {
    constructor(title, content, categories){
        this.id = uuidv4()
        this.date = new Date()
        this.title = title
        this.content = content
        this.categories = categories
    }

    getDate(objDate){
        const date = new Date(objDate || this.date)
        const hour = `${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`
        return {
            year: date.getFullYear(),
            month: date.getMonth(),
            day: date.getDay(),
            hour
        }
    }
}

export default Entry