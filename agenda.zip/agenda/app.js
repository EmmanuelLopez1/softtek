import colors from "colors"
import Entry from "./models/Entry.js";
import Diary from "./models/Diary.js";
import { mainMenu, pause } from "./helpers/inquirer.js";
import { readFile, saveFile } from "./helpers/db.js";
import { listMenu, 
        getEntryValues, 
        filterMenu, 
        showEntry,
        updateEntry} from "./helpers/diaryInquirer.js";

const main = async () => {
    const diary = new Diary()
    const entries = readFile()
    let opt
    let counter = 0
    do {
        counter += 1
        console.log(counter);
        opt = await mainMenu()

        if(entries){
            diary.loadEntries(entries)
        }
        
        switch (opt) {
            case "1":{
                const { title, text } = await getEntryValues()
                diary.addEntry(new Entry(title, text))
                break;
            }
            case "2":{
                const ans = await listMenu(["1. Year", "2. Month", "3. Day", "4. Title", "0. Exit"])
                const id = await filterMenu(ans, diary)
                if(id !== undefined){
                    showEntry(diary, id)
                    break;
                }
                console.log("Any entry finded".red);
                break;
            }
            case "3":{
                const ans = await listMenu(["1. Year", "2. Month", "3. Day", "4. Title", "0. Exit"])
                const id = await filterMenu(ans, diary)
                if(diary.deleteEntry(id)){
                    console.log("Sucessfully deleted".green)
                    break
                }
                console.log("Nothing to delete".red);
                break;
            }
            case "4":{
                const ans = await listMenu(["1. Year", "2. Month", "3. Day", "4. Title", "0. Exit"])
                const id = await filterMenu(ans, diary)
                if(id !== undefined && id !== "0"){
                    const entry = await updateEntry(diary, id)
                    diary.entries[entry.id] = entry
                }
                break;
            }
            default:
                break;
        }

        saveFile(diary.entries)
        await pause()
    } while (opt !== "0")
}

main()