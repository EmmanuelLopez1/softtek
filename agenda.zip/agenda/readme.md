What do the app do?

This app is a Diary.
-fecha.
-titulo.
-entrada.
-temas.

se guardaran por dias, meses y años.
se filtraran por dias, meses y años.
se filtrara por titulo.
se podran eliminar.
se podra actualizar la entrada y se incluira la fecha.