import fs from "fs"
const url = './db/db.json'

const saveFile = (data)=>{
    fs.writeFileSync(url, JSON.stringify(data))
}

const readFile = ()=>{
    if(!fs.existsSync(url)){
        return null
    }

    let info = fs.readFileSync(url, 'utf8')

    return JSON.parse(info)
}

export {
    readFile,
    saveFile
}