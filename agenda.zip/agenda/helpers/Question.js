import colors from "colors"

class Question{
    constructor(type, name, message, choices, validate, defaultValue, waitUserInput){
        return{
            type,
            name, 
            message,
            choices, 
            validate,
            default:defaultValue,
            waitUserInput
        }
    }
}

class QuestionBuilder {
    constructor(){
        this.reset()
    }
    reset(){
        this.type = ""
        this.name = ""
        this.message = ""
        this.choices = []
        this.validate = this.setValidate
        this.default = "",
        this.waitUserInput = false
    }

    setType(type){
        this.type = type;
        return this;
    }

    setName(name){
        if(!name){
            this.name = "ans";
        }else{
            this.name = name
        }
        return this
    }

    setMessage(message){
        this.message = `\n${message}`.magenta;
        return this
    }
    
    setChoices(arr = []){
        this.choices = arr;
        return this
    }

    setValidate(cb){
        this.validate = (ans)=>{
            if(cb){
                console.log(cb);    
                return cb(ans)
            }
            return true
        }
        return this
    }

    setDefault(data){
        this.default = data
        return this
    }

    setWaitUserInput(){
        this.waitUserInput = true
        return this
    }

    build(){
        const question = new Question(
            this.type, 
            this.name,
            this.message, 
            this.choices, 
            this.validate,
            this.default, 
            this.waitUserInput
        )
        this.reset()
        return question
    }
}

class QuestionDirector{
    constructor(questionBuilder){
        this.questionBuilder = questionBuilder
    }

    setQuestionBuilder(questionBuilder){
        this.questionBuilder = questionBuilder
    }
    
    createSimpleQuestion(type, name, message, choices, validate){
        this.questionBuilder
            .setType(type)
            .setName(name)
            .setMessage(message)
            .setChoices(choices)
            .setValidate(validate)
    }
}

export {
    Question,
    QuestionBuilder,
    QuestionDirector
}