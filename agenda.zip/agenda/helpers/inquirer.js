import colors from "colors"
import inquirer from "inquirer"
import Choices from "./Choices.js"
import { QuestionBuilder, QuestionDirector } from "./Question.js"

const questionBuilder = new QuestionBuilder()
const director = new QuestionDirector(questionBuilder)

const mainMenu = async()=>{
    console.log("=======================".green)
    console.log("   Select an option    ")
    console.log("=======================\n".green)

    const choices = [
        {
            name: "1. Create entry",
        },
        {
            name: "2. Search entry"
        },
        {
            name: "3. Delete entry",
        },
        {
            name: "4. Update entry",
        },
        {
            name: "0. Exit",
            value:"0"
        }
    ]

    // Create choices obj and set its values like a list
    const opts = new Choices(choices).setListValues()

    // create a simple question
    director.createSimpleQuestion("list", "", "Select an option", opts)

    // build the question
    const menu = questionBuilder.build()

    const { ans } = await inquirer.prompt(menu)
    return ans
}

const validateNoEmptyAnswer = (ans)=>{
    if(ans.length > 0){
        return true
    }
    return "Please enter some text"
}

const pause = async()=>{
    director.createSimpleQuestion("input", "next", "Press enter to continue", [])    
    await inquirer.prompt(questionBuilder.build())
}

export {
    mainMenu,
    pause,
    validateNoEmptyAnswer   
}