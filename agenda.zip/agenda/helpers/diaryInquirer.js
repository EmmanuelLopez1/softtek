import inquirer from "inquirer"

import Choices from "./Choices.js"
import { validateNoEmptyAnswer } from "./inquirer.js"
import { QuestionBuilder, QuestionDirector } from "./Question.js"

const questionBuilder = new QuestionBuilder()
const director = new QuestionDirector(questionBuilder)

const listMenu = async (arr) => {
    let choices = arr.map(el => {
        return { name: el }
    })

    choices = new Choices(choices).setListValues()

    director.createSimpleQuestion("list", "", "Search a entry by:", choices)
    const questions = questionBuilder.build()
    const { ans } = await inquirer.prompt(questions)
    return ans
}

const getEntryValues = async () => {
    const questions = []
    director.createSimpleQuestion("input", "title", "Enter a title", [], validateNoEmptyAnswer)
    questions.push(questionBuilder.build())
    director.createSimpleQuestion("input", "text", "Enter your entry", [], validateNoEmptyAnswer)
    questions.push(questionBuilder.build())

    const answers = await inquirer.prompt(questions)
    return answers
}

const filterMenu = async (opt, diary) => {
    switch (opt) {
        case "1":{
            const year = await filterByYear(diary)
            return await selectEntry(diary, date => {
                return date.getFullYear() === year
            })
        }
        case "2":{
            const year = await filterByYear(diary)
            const month = await filterByMonth(diary)
            return await selectEntry(diary, date => {
                return date.getMonth() === month
                    && date.getFullYear() === year
            })
        }
        case "3":{
            const year = await filterByYear(diary)
            const month = await filterByMonth(diary)
            const day = await filterByDay(diary)
            return await selectEntry(diary, date => {
                return date.getDate() === day
                    && date.getMonth() === month
                    && date.getFullYear() === year
            })
        }
        case "4":{
            return await filterByTitle(diary)
        }
        default:
            break;
    }
}

const listAll = async (diary) => {
    const entries = diary.getEntriesArr
    entries.forEach(entry => {
        console.log(diary.showEntry(entry))
    })
}

const filterByYear = async (diary) => {
    let years = []
    diary.getEntriesArr.map(entry => {
        const year = new Date(entry.date).getFullYear()
        if (!years.includes(year)) {
            years.push(year)
        }
    })

    years = years.map(year => { return { name: year, value: year } })

    director.createSimpleQuestion("list", "year_selected", "Select a year", years)
    const { year_selected } = await inquirer.prompt(questionBuilder.build())
    return Number(year_selected)
}

const filterByMonth = async (diary) => {
    let months = []
    diary.getEntriesArr.map(entry => {
        const month = new Date(entry.date).getMonth()
        if (!months.includes(month)) {
            months.push(month)
        }
    })

    months = months.map(month => {
        const date = new Date()
        date.setMonth(month)
        return {
            name: date.toLocaleString("en-US", { month: "long" }),
            value: month
        }
    })

    director.createSimpleQuestion("list", "month_selected", "Select a month", months)
    const { month_selected } = await inquirer.prompt(questionBuilder.build())
    return Number(month_selected)
}

const filterByDay = async (diary) => {
    const entries = diary.getEntriesArr
    let choices = []

    entries.forEach(entry => {
        const day = new Date(entry.date).getDate()
        if (!choices.includes(day)) {
            choices.push(day)
        }
    })


    choices = choices.map(day => {
        const date = new Date()
        date.setDate(day)
        return {
            name: date.toLocaleString(),
            value: date.toLocaleString("en-US", { day: "numeric" })
        }
    })

    director.createSimpleQuestion("list", "", "Select a day:", choices)

    const { ans } = await inquirer.prompt(questionBuilder.build())
    return Number(ans)
}

const filterByTitle = async (diary) => {
    await director.createSimpleQuestion("prompt", "", "Enter a keyword to search", [], validateNoEmptyAnswer)
    const { ans } = await inquirer.prompt(questionBuilder.build())

    let entries = []
    diary.getEntriesArr.forEach(entry => {
        if (new RegExp(ans).test(entry.title)) {
            entries.push({
                name: entry.title,
                value: entry.id
            })
        }
    })

    entries.push({
        name:"0. Exit",
        value:"0"
    })

    if (entries.length > 0) {
        await director.createSimpleQuestion("list", "", "Select an entry:", entries)
        const { ans } = await inquirer.prompt(questionBuilder.build())
        return ans
    }
}

const selectEntry = async (diary, cb) => {
    const filteredEntries = []
    diary.getEntriesArr.forEach(entry => {
        if (cb(new Date(entry.date))) {
            filteredEntries.push({name: entry.title, value: entry.id})
        }
    })

    director.createSimpleQuestion("list", "id", "Select the entry you want to see", filteredEntries)
    const { id } = await inquirer.prompt(questionBuilder.build())

    return id
}

const showEntry = (diary, id) => {
    console.log(diary.showEntry(diary.entries[id]))
}

const updateEntry = async(diary, id)=>{
    const entry = diary.entries[id]
    const questions = [
        questionBuilder
            .setType("input")
            .setName("title")
            .setMessage("Enter a title")
            .setDefault(entry.title)
            .setWaitUserInput()
            .setValidate(validateNoEmptyAnswer)
            .build(),
        questionBuilder
            .setType("editor")
            .setName("content")
            .setMessage("Edit content")
            .setDefault(entry.content)
            .setWaitUserInput()
            .setValidate(validateNoEmptyAnswer)
            .build(),
    ]
    const {title, content} = await inquirer.prompt(questions)
    entry.title = title
    entry.content = content
    return entry
}

export {
    listMenu,
    getEntryValues,
    filterMenu,
    showEntry,
    updateEntry
}