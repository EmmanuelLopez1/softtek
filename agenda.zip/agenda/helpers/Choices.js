class Choices {
    constructor(choices){
        this.choices = choices
    }

    setListValues(){
        this.choices.forEach((choice, index)=>{
            if(!choice.value){
                choice.value = `${index + 1}`
            }
        })
        return this.choices
    }
}


export default Choices