const path = require("path")
const fs = require("fs")

class Ticket {
    constructor(numero, escritorio){
        this.numero = numero;
        this.escritorio = escritorio;
    }
}

class ticketControl {
    constructor() {
        this.reset();
        this.init();
    }

    reset() {
        this.ultimo = 0;
        this.hoy = new Date().getDate();
        this.tickets = [];
        this.ultimos4 = [];
    }

    get toJson() {
        return {
            ultimo: this.ultimo,
            hoy: this.hoy,
            tickets: this.tickets,
            ultimos4: this.ultimos4
        }
    }

    init(){
        const {hoy, tickets, ultimos4, ultimo} = require("../db/data.json")
        // console.log(data); 
        if( hoy === this.hoy ){
            this.tickets = tickets;
            this.ultimos4 = ultimos4;
            this.ultimo = ultimo;
            return
        }
        this.guardarDB()
    }

    guardarDB(){
        const dbPath = path.join(__dirname, "../db/data.json");
        fs.writeFileSync(dbPath, JSON.stringify( this.toJson ));
    }

    siguiente(){
        this.ultimo += 1;

        this.tickets.push( new Ticket(this.ultimo, null) )
        this.guardarDB()
        return 'Ticket ' + this.ultimo
    }

    atenderTicket( escritorio ){
        // no hay tickets
        if(this.tickets.length === 0){
            return null;
        }

        const ticket = this.tickets.shift();
        ticket.escritorio = escritorio;

        this.ultimos4.unshift(ticket)

        if(this.ultimos4.length > 4){
            this.ultimos4 = this.tickets.slice(0, 3)
        }

        this.guardarDB();
        return ticket;
    }
}

module.exports = ticketControl;