const TicketControl = require("../models/ticket-control");

const ticketControl = new TicketControl()

const socketController = (socket) => {
    socket.emit('ultimo-ticket', ticketControl.ultimo)
    socket.emit('estado-actual', ticketControl.ultimos4)
    socket.emit('tickets-pendientes', ticketControl.tickets.length)
    socket.broadcast.emit('tickets-pendientes', ticketControl.tickets.length)

    socket.on('siguiente-ticket', (payload, callback) => {
        socket.emit('estado-actual', ticketControl.ultimos4)
        const ticket = ticketControl.siguiente()
        callback(ticket)
        socket.emit('tickets-pendientes', ticketControl.tickets.length)
        socket.broadcast.emit('tickets-pendientes', ticketControl.tickets.length)

        // NOTIFICAR QUE HAY UN NUEVO TICKET PENDIENTE QUE ASIGNAR
    })

    socket.on('atender-ticket', ({ escritorio }, cb) => {
        if (!escritorio) {
            return cb({
                ok: false,
                msg: "Escritorio inexistente"
            })
        }

        const ticket = ticketControl.atenderTicket(escritorio)
        socket.broadcast.emit('estado-actual', ticketControl.ultimos4)
        socket.emit('tickets-pendientes', ticketControl.tickets.length)
        socket.broadcast.emit('tickets-pendientes', ticketControl.tickets.length)


        if (!ticket) {
            cb({
                ok: false,
                msg: "No hay tickets pendientes"
            })
        }

        cb({
            ok: true,
            ticket
        })
    })

}



module.exports = {
    socketController
}

