// Referencias HTML
const lblEscritorio = document.querySelector("h1")
const btnAtender = document.querySelector("button")
const divAlerta = document.querySelector(".alert")
const lblPendientes = document.querySelector("#lblPendientes")

// GET URL PARAMS
const searhParams = new URLSearchParams(window.location.search)

if( !searhParams.has("escritorio") ){
    window.location = "index.html"
    throw new Error("El escritorio es obligatorio")
}

const escritorio = searhParams.get("escritorio")
lblEscritorio.innerHTML = escritorio;

divAlerta.style.display = "none"

const socket = io();

socket.on('ultimo-ticket', (ultimoTicket) => {
    // lblNuevoTicket.innerHTML = `Ticket ${ultimoTicket}`
});

socket.on('tickets-pendientes', ( pendientes )=>{
    if(pendientes === 0){
       return lblPendientes.style.display = "none"
    }
    lblPendientes.style.display = "block"
    lblPendientes.innerHTML = pendientes
})

btnAtender.addEventListener( 'click', () => {    
    socket.emit( 'atender-ticket', { escritorio }, ( {ok, ticket, msg} ) => {
        if(ok){
            lblEscritorio.innerHTML = ticket.numero
            divAlerta.style.display = "none"
            
        }else{
            divAlerta.style.display = ""
            lblEscritorio.innerHTML = "nadie"
        }
    });
});