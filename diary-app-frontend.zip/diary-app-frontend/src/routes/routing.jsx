import {
    createBrowserRouter 
} from "react-router-dom";
import Layout from "../Containers/Layout"
import Entries from "../pages/Entries";
import Home from '../pages/Home'
import AddEntry from "../pages/AddEntry";

const router = createBrowserRouter([
    {
        path: "/",
        element: <Layout><Home/></Layout>,
    },
    {
        path: "/entries",
        element: <Layout><Entries/></Layout>,
    },
    {
        path:"/new-entry",
        element:<Layout><AddEntry/></Layout>
    }
]);

export default router;