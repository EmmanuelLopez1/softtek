class Config {
    constructor(){
        this.devUrl = "http://localhost:3000"
        this.productionUrl = "https://diary-app-nt6u.onrender.com"
        this.entriesUrl = `${this.productionUrl}/api/entries`
    }
}

export default new Config()