import Config from "../assets/config"

const addEntry = async(payload)=>{
    let data = await fetch(Config.entriesUrl, {
        method:"post",
        headers:{
            'Content-Type': 'application/json'
        },
        body:JSON.stringify(payload)
    })
    return data.status
}

export default addEntry