import config from "../assets/config"

const getEntries = async ()=>{
    let entries = await fetch(config.entriesUrl,{
        headers:{
            'Content-Type': 'application/json'
        }
    })
    entries = await entries.json()
    return entries
}

export default getEntries