import { useRef } from 'react'
import {
    Col,
    Container,
    Row,
    Button,
    Form
} from "react-bootstrap"
import newEntry from "../hooks/useAddEntry"
import '../styles/AddEntry.scss'

const AddEntry = () => {
    let title = useRef()
    let entry = useRef()
    let date = useRef()
    let time = useRef()

    const createEntry = async () => {
        title = title.current.value
        entry = entry.current.value
        date = date.current.value
        time = time.current.value
        if (time !== '') {
            date = new Date(date)
            console.log(date);
            date.setHours(time.substr(0, 2), time.substr(3))
        }

        console.log(date)
        
        const payload = {
            title: title,
            text: entry,
            date: date,
        }
        const status = await newEntry(payload)

        if (status === 200) {
            alert("entrada creada existosamente")
        } else {
            alert("ocurrio un error al crear la entrada")
        }
        window.location.reload()
    }

    return (
        <div className="AddEntry">
            <Container>
                <Row>
                    <Col xs="8"
                        style={{
                            margin: "auto"
                        }}>
                        <Form>
                            <h4 style={{
                                marginBottom: "10px"
                            }}>Create new entry:</h4>
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Form.Control
                                    ref={title}
                                    type="text"
                                    placeholder="Title" />
                            </Form.Group>
                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                <Row>
                                    <Col xs="5">
                                        <Form.Control
                                            ref={date}
                                            type="date" />
                                    </Col>
                                    <Col xs="5">
                                        <Form.Control
                                            ref={time}
                                            type="time" />
                                    </Col>
                                </Row>
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="formBasicPassword">
                                <Form.Control
                                    ref={entry}
                                    as="textarea"
                                    placeholder="Description"
                                    style={{
                                        maxHeight: "200px",
                                        height: "200px"
                                    }} />
                            </Form.Group>
                            <Button
                                variant="primary"
                                onClick={() => {
                                    createEntry(title, entry, date)
                                }}>
                                Save
                            </Button>
                        </Form>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default AddEntry
