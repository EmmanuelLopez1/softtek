import {useEffect, useState} from 'react'
import { v4 as uuidv4 } from 'uuid';
import getEntries from '../hooks/useGetEntries'
import Entry from "../components/Entry"
import "../styles/Entries.scss"
import Loader from '../components/Loader'

const Entries = () => {
    const [entries, setEntries] = useState([])
    const [loader, setLoader] = useState(true)
    useEffect(() => {
        setLoader(true)
        getEntries()
            .then(data=>{
                setEntries(data)
                setLoader(false)
            })
            .catch(err=>{
                console.log(err)
            })
    }, [])
    
    return (
        <div className="Entries" >
            <Loader loader={loader}/>
            {
                entries.map(entry=>{
                    return <Entry key={uuidv4()} payload={entry}/>
                })
            }
        </div>
    )
}

export default Entries