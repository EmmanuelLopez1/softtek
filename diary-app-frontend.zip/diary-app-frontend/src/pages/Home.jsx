import {
  Container,
  Row,
  Col
} from "react-bootstrap"
import InfoCard from "../components/InfoCard"
import author_img from "../assets/img/author.jpg"
import "../styles/Home.scss"

const Home = () => {
  return (
    <div className="Home">
      <Container>
        <Row className="justify-content-center">
          <Col>
            <div className="author_info">
              <h2>
                About this page:
              </h2>
              <div className="circular--landscape box-shadow-cyberpunk-degradate-small">
                <img src={author_img} className="box-shadow-cyberpunk-degradate"/>
              </div>
            </div>
          </Col>
        </Row>
        <Row className="justify-content-center">
          <Col xs="10">
            <InfoCard title="Notas">
              <p>
                Hola!!
                <br />
                Bienvenido a mi blog, decidi realizar esta aplicacion porque la que estaba usando no funciona,
                ademas es un proyecto sencillo y no tenia mucho mas que hacer.
              </p>
              <p>
                Tambien me sirve para practicar, me esta gustando bastante como va quedando.
                <br />
                <br />
                Supongo que le ire agregando mas funcionalidades con el tiempo, siente libre de navegar por todas las entradas.
              </p>
              <br/>
              <footer className="blockquote-footer">
                Author: @Maxo
              </footer>
            </InfoCard>
          </Col>
        </Row>
      </Container>
    </div>
  )
}

export default Home