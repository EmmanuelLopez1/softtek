class Entries {
    constructor(){
        this.Entries = []
    }

    
}

export default Entries