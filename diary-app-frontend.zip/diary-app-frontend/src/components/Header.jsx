import React from 'react'
import "../styles/Header.scss"
import Navigation from '../components/Navbar'
const Header = () => {
  return (
    <div className="Header">
        <Navigation/>
    </div>
  )
}

export default Header