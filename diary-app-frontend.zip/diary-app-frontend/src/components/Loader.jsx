import '../styles/Loader.scss'
const Loader = ({ loader }) => {
    return (
        <>
            {
                loader &&
                <div className="Loader_container">
                    <span className="Loader"></span>
                </div>
            }
        </>
    )
}

export default Loader