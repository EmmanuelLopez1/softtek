import React from 'react'
import {
    Button,
    Card,
    Container,
    Row,
    Col
} from 'react-bootstrap'
import '../styles/Entry.scss'

const Entry = ({ payload }) => {
    let { title, text, date } = payload
    date = new Date(date)
    const formatDate = `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`
    const formatTime =  `${date.toTimeString().substr(0, 8)}`
    return (
        <div className='Entry'>
            <Container>
                <Row>
                    <Col lg="9" style={{margin:"auto"}}>
                        <Card className='box-shado-degradate'>
                            <Card.Header>
                                {`${formatDate} 
                                - ${formatTime} ${Number(formatTime.substr(0, 2)) >= 12 ? "pm": "am"}`}
                            </Card.Header>
                            <Card.Body>
                                <Card.Title>
                                    {
                                        title && title
                                    }
                                </Card.Title>
                                <Card.Text>
                                    {text}
                                </Card.Text>
                                {/* <Button variant="primary">
                                    View detail
                                </Button> */}
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default Entry
