import React from 'react'

const Footer = () => {
  return (
    <div className="Footer">
        
    </div>
  )
}

export default Footer