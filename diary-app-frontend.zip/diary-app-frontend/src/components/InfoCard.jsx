import Card from 'react-bootstrap/Card';
import '../styles/InfoCard.scss'

function InfoCard({title, children}) {
  return (
    <Card className="InfoCard box-shado-degradate">
      <Card.Header>{title}</Card.Header>
      <Card.Body>
        {
          children
        }
      </Card.Body>
    </Card>
  );
}

export default InfoCard;